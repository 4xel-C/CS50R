ducksay <- function(phrase = "Hello, world") {
    paste(
        phrase,
        ">(. )__",
        " (____/\n",
        sep = "\n"
    )
}
